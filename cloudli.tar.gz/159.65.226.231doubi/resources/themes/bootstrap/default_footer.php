<div class="footer">
    <a href="https://github.com/vpslinuxinstall" target="_blank">cloudli</a> / <a href="https://github.com/vpslinuxinstall" target="_blank">Github开源</a> · 基于 <a href="http://www.directorylister.com/" target="_blank">Directory Lister</a> © 2015-<?php echo date("Y")?>
</div>
